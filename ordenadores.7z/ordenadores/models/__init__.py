from . import ordenador, tipos, ofertas, proveedores
